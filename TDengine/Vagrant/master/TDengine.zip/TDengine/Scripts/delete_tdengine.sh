#!/bin/bash
rpm -e tdengine
rm -rf  /var/lib/taos
rm -rf  /var/log/taos
