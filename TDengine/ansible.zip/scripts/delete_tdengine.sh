#!/bin/bash
sudo rpm -e tdengine
sudo rm -rf  /var/lib/taos
sudo rm -rf  /var/log/taos
sudo rm -rf  /etc/taos